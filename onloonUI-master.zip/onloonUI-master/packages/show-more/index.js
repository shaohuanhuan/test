/**
 * @author monkeywang
 * Date: 17/5/26
 */
import LxShowMore from './src/show-more.vue'

LxShowMore.install = function(Vue) {
  Vue.component(LxShowMore.name, LxShowMore)
}

export default LxShowMore
